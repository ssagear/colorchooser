# plotpainter

This GUI app allows you to change the colors of your matplotlib plots only using a matplotlib Figure object.
