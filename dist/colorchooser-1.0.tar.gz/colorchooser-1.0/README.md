# colorchooser

GUI to change the color of your Matplotlib plots.
